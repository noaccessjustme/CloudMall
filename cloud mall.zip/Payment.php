<?php
require_once 'session.php';
require_once 'dbconn.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fetch all shops from the database
$shopQuery = "SELECT shop_id, shop_name FROM shops";
$shopStmt = $conn->prepare($shopQuery);
$shopStmt->execute();
$shops = $shopStmt->get_result();

while ($shop = $shops->fetch_assoc()) {
    echo '<a href="Payment.php?shop_id=' . $shop['shop_id'] . '">' . htmlspecialchars($shop['shop_name']) . '</a><br>';
}

// Check if the shop_id is provided in the URL
if (!isset($_GET['shop_id'])) {
    echo "Shop not found! Please select a shop.";
    exit();
}

// Get the shop_id from the URL
$shop_id = intval($_GET['shop_id']);

// Fetch total amount from the carts table for the specific shop
$user_id = $_SESSION['user_id'];
$query = "SELECT SUM(total) as total FROM carts WHERE user_id = ? AND shop_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $user_id, $shop_id);
$stmt->execute();
$result = $stmt->get_result();
$total_data = $result->fetch_assoc();
$totalAmount = $total_data['total'] ? $total_data['total'] : 0;

// Fetch user email from the database
$email_query = "SELECT email FROM users WHERE user_id = ?";
$email_stmt = $conn->prepare($email_query);
$email_stmt->bind_param("i", $user_id);
$email_stmt->execute();
$email_result = $email_stmt->get_result();
$user_email = $email_result->fetch_assoc()['email'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $delivery_option = $_POST['delivery_option'];
    $address = $delivery_option === 'delivery' ? $_POST['address'] : null;
    $contact = $delivery_option === 'delivery' ? $_POST['contact'] : null;
    $payment_method = $_POST['payment_method'];
    $total_amount = $_POST['total_amount'];
    $user_email = $_POST['user_email'];

    // Process payment here (PayPal or Credit Card)
    // For demo purposes, we will skip actual payment processing.

    // After successful payment, send confirmation email
    $subject = "Payment Confirmation";
    $message = "Thank you for your payment of $" . number_format($total_amount, 2) . ".\n";
    if ($delivery_option === 'delivery') {
        $message .= "Your items will be delivered to: $address\nContact Number: $contact";
    } else {
        $message .= "Your items will be available for self-collection.";
    }
    $message .= "\n\nThank you for shopping with us!";
    
    // Send email
    mail($user_email, $subject, $message, "From: no-reply@yourwebsite.com");

    // Redirect to orders page
    header("Location: orders.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        h1 {
            text-align: center;
            color: #fbc02d; 
        }

        .payment-option {
            margin-top: 20px;
        }

        .hidden {
            display: none;
        }

        .button {
            padding: 10px 20px;
            background-color: #333;
            color: #fbc02d;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 10px;
            display: inline-block;
        }

        .button:hover {
            background-color: #555;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
        }

        .input-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }

    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

<a href="Products.php" class="back-button">
    <i class="fas fa-arrow-left"></i>
</a>

<div class="container">
    <h1>Payment</h1>

    <p>Total Amount: $<?= number_format($totalAmount, 2); ?></p>

    <div class="payment-option">
        <label for="collection-option">
            <input type="radio" name="delivery_option" id="collection-option" value="self" checked>
            Self Collection
        </label>
        <label for="delivery-option">
            <input type="radio" name="delivery_option" id="delivery-option" value="delivery">
            Delivery
        </label>
    </div>

    <div id="delivery-details" class="hidden">
        <h3>Delivery Details</h3>
        <div class="input-group">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" placeholder="Enter your delivery address">
        </div>
        <div class="input-group">
            <label for="contact">Contact Number:</label>
            <input type="text" id="contact" name="contact" placeholder="Enter your contact number">
        </div>
    </div>

    <div class="payment-option">
        <h3>Select Payment Method:</h3>
        <label for="paypal-option">
            <input type="radio" name="payment_method" id="paypal-option" value="paypal" checked>
            PayPal
        </label>
        <label for="credit-card-option">
            <input type="radio" name="payment_method" id="credit-card-option" value="credit_card">
            Credit Card
        </label>
    </div>

    <div id="payment-details">
        <div id="paypal-details" class="payment-inputs">
            <h3>PayPal Payment Details</h3>
            <div class="input-group">
                <label for="paypal-email">PayPal Email:</label>
                <input type="email" id="paypal-email" name="paypal_email" placeholder="Enter your PayPal email">
            </div>
        </div>

        <div id="credit-card-details" class="payment-inputs hidden">
            <h3>Credit Card Payment Details</h3>
            <div class="input-group">
                <label for="card-number">Card Number:</label>
                <input type="text" id="card-number" name="card_number" placeholder="Enter your card number">
            </div>
            <div class="input-group">
                <label for="expiry-date">Expiry Date (MM/YY):</label>
                <input type="text" id="expiry-date" name="expiry_date" placeholder="MM/YY">
            </div>
            <div class="input-group">
                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" name="cvv" placeholder="Enter CVV">
            </div>
        </div>
    </div>

    <a href="Orders.php"><button class="button" id="submit-payment">Submit Payment</button></a>
</div>

<script>
    document.querySelectorAll('input[name="delivery_option"]').forEach((elem) => {
        elem.addEventListener("change", function(event) {
            const deliveryDetails = document.getElementById("delivery-details");
            if (event.target.value === "delivery") {
                deliveryDetails.classList.remove("hidden");
            } else {
                deliveryDetails.classList.add("hidden");
            }
        });
    });

    document.querySelectorAll('input[name="payment_method"]').forEach((elem) => {
        elem.addEventListener("change", function(event) {
            const paypalDetails = document.getElementById("paypal-details");
            const creditCardDetails = document.getElementById("credit-card-details");

            if (event.target.value === "paypal") {
                paypalDetails.classList.remove("hidden");
                creditCardDetails.classList.add("hidden");
            } else {
                paypalDetails.classList.add("hidden");
                creditCardDetails.classList.remove("hidden");
            }
        });
    });
</script>

</body>
</html>
