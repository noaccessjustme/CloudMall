<?php
require_once 'session.php';  // For session management
require_once 'dbconn.php';  // Database connection

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['email'];
    $password = $_POST['password'];
    $shop_id = isset($_POST['shop_id']) ? intval($_POST['shop_id']) : null;  // Get the shop_id from the form

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT hash_password FROM users WHERE email = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Check if user exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            $_SESSION['loggedin'] = true;  // Set session variable
            $_SESSION['email'] = $username;  // Store username in session
            
            // Redirect to the products page for the specific store after login
            header("Location: Products.php?shop_id=" . $shop_id);
            exit;
        } else {
            $error = "Invalid email or password!";
        }
    } else {
        $error = "Invalid email or password!";
    }
    $stmt->close();  // Close statement
}

// Logout functionality
if (isset($_GET['logout'])) {
    session_destroy();  // Destroy the session
    header("Location: OnlineShopping.php");
    exit;
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'];

// Fetch stores from the database
$query = "SELECT * FROM shops";
$result = $conn->query($query);

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Shops</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            border: none;
        }

        /* Body styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff; /* White background */
            color: #333;
            padding: 20px;
        }

        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
        }

        /* Header styling */
        header {
            text-align: center;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 36px;
            color: #fbc02d; /* Yellow */
        }

        /* Shop List Styling */
        .shop-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        /* Shop Item Styling */
        .shop-item {
            text-align: center;
            background-color: #333; /* Black background */
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s ease;
            text-decoration: none; /* Remove underline */
        }

        .shop-item:hover {
            transform: scale(1.05);
        }

        .shop-item h2 {
            color: #fbc02d; /* Yellow text */
            margin-top: 15px;
            font-size: 22px;
        }

        /* Shop Logo Styling */
        .shop-logo {
            max-width: 150px;
            height: auto;
            border-radius: 20px;
            background-color: #fff;
            padding: 10px;
        }

        /* Modal Styling */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.5); /* Black w/ opacity */
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 30px;
            border-radius: 10px;
            width: 80%; /* Could be more or less, depending on screen size */
            max-width: 400px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Login Form Styling */
        .login-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .login-form label {
            font-size: 16px;
            font-weight: bold;
            color: #333;
        }

        .login-form input {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .login-form button {
            padding: 10px 20px;
            background-color: #333;
            color: #fbc02d; /* Yellow */
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-form button:hover {
            background-color: #555; /* Darker background on hover */
        }

        /* Logout Button Styling */
        .logout-btn {
            text-align: center;
            margin-top: 20px;
        }

        .logout-btn a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333; 
            color: #fbc02d; 
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .logout-btn a:hover {
            background-color: #555;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }

    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    
</head>
<body>

<a href="OnlineShopping.php" class="back-button">
    <i class="fas fa-arrow-left"></i>
</a>

    <div class="container">
        <header>
            <h1>Our Shops</h1>
        </header>

        <?php if (!$isLoggedIn): ?>
            <div class="error"><?php echo isset($error) ? $error : ''; ?></div>
        <?php endif; ?>

        <section class="shop-list">
            <?php
            // Loop through each store and generate the shop items
            while ($shop = $result->fetch_assoc()):
                if ($isLoggedIn): ?>
                    <a class="shop-item" href="Products.php?shop_id=<?= $shop['shop_id']; ?>">
                        <img class="shop-logo" src="<?= $shop['shop_logo']; ?>" alt="<?= $shop['shop_name']; ?> Logo">
                        <h2><?= $shop['shop_name']; ?></h2>
                    </a>
                <?php else: ?>
                    <a class="shop-item" href="javascript:void(0)" onclick="openLoginModal(<?= $shop['shop_id']; ?>)">
                        <img class="shop-logo" src="<?= $shop['shop_logo']; ?>" alt="<?= $shop['shop_name']; ?> Logo">
                        <h2><?= $shop['shop_name']; ?></h2>
                    </a>
                <?php endif;
            endwhile;
            ?>
        </section>

        <!-- Login Modal -->
        <div id="loginModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="document.getElementById('loginModal').style.display='none'">&times;</span>
                <h2>Login</h2>
                <form class="login-form" method="POST">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                    <input type="hidden" id="shop_id" name="shop_id" value=""> <!-- Hidden field for shop_id -->
                    <button type="submit" name="login">Login</button>
                </form>
            </div>
        </div>

        <?php if ($isLoggedIn): ?>
            <!-- Logout Button -->
            <div class="logout-btn">
                <a href="?logout=true">Logout</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- JavaScript for Modal -->
    <script>
        // Open login modal and pass the shop_id
        function openLoginModal(shop_id) {
            document.getElementById('loginModal').style.display = 'block';
            document.getElementById('shop_id').value = shop_id; // Set the hidden shop_id
        }

        // Close modal
        window.onclick = function(event) {
            var modal = document.getElementById("loginModal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

</body>
</html>
