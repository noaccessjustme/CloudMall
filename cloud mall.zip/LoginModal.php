<?php
require_once 'session.php';
require_once 'dbconn.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- Modal for Login -->
    <div id="loginModal" class="modal" style="display: <?= !$isLoggedIn ? 'block' : 'none'; ?>">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Please Sign In</h2>
            <form class="login-form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <button type="submit" name="login">Log In</button>
            </form>
        </div>
    </div>

    <script>
        // Open the modal
        function openModal() {
            document.getElementById('loginModal').style.display = 'block';
        }

        // Close the modal
        function closeModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            const modal = document.getElementById('loginModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>