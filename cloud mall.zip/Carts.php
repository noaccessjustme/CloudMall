<?php
require_once 'session.php'; // Include session management
require_once 'dbconn.php'; // Include database connection

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize the carts session for multiple shops if it doesn't exist
if (!isset($_SESSION['carts'])) {
    $_SESSION['carts'] = [];
}

// Check if shop_id is provided, and validate it
if (!isset($_GET['shop_id']) || !is_numeric($_GET['shop_id'])) {
    echo "Shop not found! Please select a valid shop.";
    exit();
}

$shop_id = intval($_GET['shop_id']); // Get the current shop ID

// Debug: check if shop_id is being passed
echo "Debug: Shop ID is " . $shop_id . "<br>"; // This will display the shop ID

// Initialize cart for the current shop if it doesn't exist
if (!isset($_SESSION['carts'][$shop_id])) {
    $_SESSION['carts'][$shop_id] = [];
}

// Fetch products from the cart stored in the session for the current shop
$cartItems = $_SESSION['carts'][$shop_id];

// Handle adding an item to the cart (if a form submission occurred)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];

    // Check if the product is already in the cart
    if (isset($cartItems[$productId])) {
        $cartItems[$productId]['quantity'] += 1;
    } else {
        // Add new product to the cart
        $cartItems[$productId] = ['quantity' => 1];
    }

    // Update the session with the new cart data
    $_SESSION['carts'][$shop_id] = $cartItems;
    header("Location: Carts.php?shop_id=$shop_id");
    exit();
}

// Get product details from the database for each cart item
$productIds = array_keys($cartItems);
$products = [];

if (!empty($productIds)) {
    // Merge the product IDs and shop_id into one array
    $params = array_merge($productIds, [$shop_id]);

    // Prepare placeholders for the query
    $placeholders = implode(',', array_fill(0, count($productIds), '?')) . ',?';

    // Prepare the query to fetch product details from the database
    $stmt = $conn->prepare("
        SELECT p.product_id, p.product_name, sp.price, p.image_url
        FROM products p
        JOIN shopproducts sp ON p.product_id = sp.product_id
        WHERE p.product_id IN ($placeholders) AND sp.shop_id = ?
    ");

    // Bind the merged array (product IDs and shop ID) to the query
    $stmt->bind_param(str_repeat('i', count($productIds) + 1), ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $products = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart for Shop #<?php echo $shop_id; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin: 20px;
            color: #333;
        }
        /* Cart List Styling */
        .cart-items {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px;
        }
        .cart-item {
            border: 1px solid #ddd;
            padding: 20px;
            text-align: center;
            background-color: #fff;
        }
        .cart-item img {
            max-width: 100%;
            height: auto;
        }
        .cart-item h3 {
            margin: 10px 0;
        }
        .cart-item p {
            margin: 5px 0;
        }
        .cart-total {
            font-weight: bold;
            font-size: 1.5em;
            text-align: right;
            margin-right: 20px;
        }
        /* Checkout Button */
        .checkout-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            text-align: center;
            display: block;
            width: fit-content;
            margin: 20px auto;
            text-decoration: none;
            border-radius: 5px;
        }
        .checkout-btn:hover {
            background-color: #218838;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }
    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

    <a href="OnlineShopping.php" class="back-button">
    <i class="fas fa-arrow-left"></i> Back to Shops</a>

    <h1>Your Cart for Shop #<?php echo $shop_id; ?></h1>
    <div class="cart-items">
        <?php if (!empty($products)): ?>
            <?php
            $total = 0;
            foreach ($products as $product):
                $quantity = $cartItems[$product['product_id']]['quantity'];
                $subtotal = $quantity * $product['price'];
                $total += $subtotal;
            ?>
                <div class="cart-item">
                    <img src="<?php echo $product['image_url']; ?>" alt="<?php echo $product['product_name']; ?>">
                    <h3><?php echo $product['product_name']; ?></h3>
                    <p>Quantity: <?php echo $quantity; ?></p>
                    <p>Price: R<?php echo number_format($product['price'], 2); ?></p>
                    <p>Subtotal: R<?php echo number_format($subtotal, 2); ?></p>
                </div>
            <?php endforeach; ?>
            <div class="cart-total">
                Total: R<?php echo number_format($total, 2); ?>
            </div>
            <a href="Payment.php?shop_id=<?php echo $shop_id; ?>" class="checkout-btn">Proceed to Checkout</a>
        <?php else: ?>
            <p>Your cart is empty!</p>
        <?php endif; ?>
    </div>
</body>
</html>
