<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        /* Reset styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    border: none; /* No borders */
}

/* Body styling */
body {
    font-family: 'Arial', sans-serif;
    background-color: #fff; /* White background */
    color: #333;
    padding: 20px;
}

/* Container */
.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background-color: #fff;
}

/* Header styling */
header {
    text-align: center;
    margin-bottom: 30px;
}

header h1 {
    font-size: 36px;
    color: #fbc02d; /* Yellow */
}

/* Section Titles */
h2 {
    font-size: 28px;
    color: #333;
    margin-bottom: 15px;
}

/* Section Styling */
section {
    margin-bottom: 30px;
}

section p {
    font-size: 18px;
    line-height: 1.6;
    margin-bottom: 20px;
}

/* Values List */
ul {
    list-style-type: none;
    padding-left: 0;
}

ul li {
    font-size: 18px;
    margin-bottom: 10px;
}

/* Testimonials */
blockquote {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    font-style: italic;
    font-size: 18px;
    margin-bottom: 20px;
}

blockquote cite {
    display: block;
    margin-top: 10px;
    font-size: 16px;
    color: #333;
}

/* Contact section */
.contact p {
    font-size: 18px;
}

.contact a {
    color: #fbc02d; /* Yellow link */
    text-decoration: none;
}

.contact a:hover {
    text-decoration: underline;
}

.back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }

    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<a href="OnlineShopping.php" class="back-button">
<i class="fas fa-arrow-left"></i></a>
    <div class="container">
        <header>
            <h1>About Us</h1>
        </header>

        <section class="company-intro">
            <h2>Who We Are</h2>
            <p>We are a modern business based in East London, specializing in delivering top-notch products and services that cater to the needs of our clients. This is your All-In_One stop for antproduct you might thimnk of. Located at 02 St Michaels, Southernwood, our business is committed to providing an excellent customer experience and high-quality offerings.</p>
        </section>

        <section class="mission">
            <h2>Our Mission</h2>
            <p>Our mission is to deliver exceptional value to our customers through innovative solutions and superior service. We aim to be the leading provider in our industry, consistently exceeding customer expectations.</p>
        </section>

        <section class="values">
            <h2>Our Core Values</h2>
            <ul>
                <li><strong>Integrity:</strong> We act with honesty and transparency in everything we do.</li>
                <li><strong>Customer Focus:</strong> Our customers are at the heart of everything we do.</li>
                <li><strong>Innovation:</strong> We strive to bring new and creative solutions to the table.</li>
                <li><strong>Quality:</strong> We are dedicated to delivering the highest quality services.</li>
                <li><strong>Collaboration:</strong> We believe in teamwork and the power of partnerships.</li>
            </ul>
        </section>

        <section class="history">
            <h2>Our Journey</h2>
            <p>Founded in [Year], our business started with a small but passionate team. Over the years, we’ve grown into a trusted name in the industry, expanding our services and building long-term relationships with our clients.</p>
        </section>

        <section class="team">
            <h2>Meet Our Team</h2>
            <p>We are a team of dedicated professionals committed to helping you succeed. Our experienced and talented team members are always ready to assist and ensure that you receive the best possible service.</p>
        </section>

        <section class="achievements">
            <h2>Our Achievements</h2>
            <ul>
                <li>Recognized as one of the top businesses in South Africa in [2024].</li>
                <li>Partnered with Shoprite, Checkers, Boxer, Pick'n Pay and more big cooperations to bring value to our customers.</li>
                <li>Expanded our services to reach large number of satisfied clients globally.</li>
            </ul>
        </section>

        <section class="testimonials">
            <h2>What Our Clients Say</h2>
            <blockquote>
                <p>"This company has truly transformed our business operations. Their attention to detail and customer service is unmatched!"</p>
                <cite>— Vusi Thembekwayo, CEO of XYZ Corp.</cite>
            </blockquote>
            <blockquote>
                <p>"Reliable, efficient, and innovative — we couldn’t have asked for a better partner."</p>
                <cite>— Mpho Kgomo, Founder of ABC Enterprises.</cite>
            </blockquote>
        </section>

        <section class="contact">
            <h2>Contact Us</h2>
            <p>If you'd like to learn more about what we do or how we can help you, feel free to <a href="Contact.php">contact us</a>. We'd love to hear from you!</p>
        </section>

    </div>
</body>
</html>
