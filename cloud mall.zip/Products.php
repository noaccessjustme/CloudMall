<?php
require_once 'session.php';
require_once 'dbconn.php';  // Include database connection

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the shop_id is provided in the URL
if (!isset($_GET['shop_id'])) {
    echo "Shop not found! Please select a shop.";
    exit();
}

// Get the shop_id from the URL
$shop_id = intval($_GET['shop_id']);

// Fetch products for the specific shop
$query = "SELECT p.product_id, p.product_name, p.product_description, p.image_url, sp.price, sp.stock 
          FROM products p
          JOIN shopproducts sp ON p.product_id = sp.product_id
          WHERE sp.shop_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $shop_id);
$stmt->execute();
$products = $stmt->get_result();

// Add to cart functionality
if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);
    $user_id = $_SESSION['user_id']; // Assuming user is logged in and user_id is in session
    $quantity = 1; // Default quantity

    // Fetch product details
    $stmt = $conn->prepare("SELECT p.product_name, sp.price 
                            FROM products p
                            JOIN shopproducts sp ON p.product_id = sp.product_id
                            WHERE p.product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        $price = $product['price'];
        $total = $price * $quantity; // Calculate total for one item

        // Check if the item already exists in the user's cart
        $stmt = $conn->prepare("SELECT * FROM carts WHERE user_id = ? AND shop_id = ? AND product_id = ?");
        $stmt->bind_param("iii", $user_id, $shop_id, $product_id);
        $stmt->execute();
        $existing_cart_item = $stmt->get_result()->fetch_assoc();

        if ($existing_cart_item) {
            // If item exists, update the quantity and total in the database
            $new_quantity = $existing_cart_item['quantity'] + 1;
            $new_total = $new_quantity * $price;

            $update_stmt = $conn->prepare("UPDATE carts 
                                           SET quantity = ?, total = ?, updated_at = NOW()
                                           WHERE user_id = ? AND shop_id = ? AND product_id = ?");
            $update_stmt->bind_param("idiii", $new_quantity, $new_total, $user_id, $shop_id, $product_id);
            $update_stmt->execute();
        } else {
            // If item does not exist, insert it as a new cart item
            $insert_stmt = $conn->prepare("INSERT INTO carts (cart_id, user_id, shop_id, product_id, quantity, total) 
                                           VALUES (?, ?, ?, ?, ?, ?)");
            $insert_stmt->bind_param("iiiidd", $cart_id, $user_id, $shop_id, $product_id, $quantity, $total);
            $insert_stmt->execute();
        }

        // Update the session cart for immediate feedback
        if (!isset($_SESSION['carts'][$shop_id])) {
            $_SESSION['carts'][$shop_id] = [];
        }
        if (isset($_SESSION['carts'][$shop_id][$product_id])) {
            $_SESSION['carts'][$shop_id][$product_id]['quantity'] += 1;
        } else {
            $_SESSION['carts'][$shop_id][$product_id] = [
                'name' => $product['product_name'],
                'price' => $price,
                'quantity' => $quantity
            ];
        }
    }

    // Redirect back to the products page
    header("Location: Products.php?shop_id=$shop_id");
    exit();
}

// Remove item from the cart
if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    
    // Remove item from session
    if (isset($_SESSION['carts'][$shop_id][$remove_id])) {
        unset($_SESSION['carts'][$shop_id][$remove_id]);
    }

    // Remove item from database
    $stmt = $conn->prepare("DELETE FROM carts WHERE user_id = ? AND shop_id = ? AND product_id = ?");
    $stmt->bind_param("iii", $_SESSION['user_id'], $shop_id, $remove_id);
    $stmt->execute();

    header("Location: Products.php?shop_id=$shop_id");
    exit();
}

// Initialize the cart in session if it doesn't exist to avoid errors
if (!isset($_SESSION['carts'][$shop_id])) {
    $_SESSION['carts'][$shop_id] = [];
}

// Calculate the total amount in the cart for the specific shop
$totalAmount = array_reduce($_SESSION['carts'][$shop_id], function ($sum, $item) {
    return $sum + ($item['price'] * $item['quantity']);
}, 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff;
            color: #333;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
        }

        header {
            text-align: center;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 36px;
            color: #fbc02d; /* Yellow */
        }

        .product-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .product-item {
            text-align: center;
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        .product-item:hover {
            transform: scale(1.05);
        }

        .product-item img {
            max-width: 150px;
            height: auto;
            border-radius: 10px;
        }

        .product-item h3 {
            color: #fbc02d;
            margin-top: 15px;
            font-size: 22px;
        }

        .product-item p {
            color: #fff;
        }

        .product-item a {
            color: #fbc02d;
            text-decoration: none;
            font-weight: bold;
        }

        .cart {
            margin-top: 30px;
        }

        .cart ul {
            list-style: none;
        }

        .cart li {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .checkout-btn {
            padding: 10px 20px;
            background-color: #333;
            color: #fbc02d;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
        }

        .checkout-btn:hover {
            background-color: #555;
        }

        .toggle-cart {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .toggle-cart:hover {
            background-color: #555;
        }

        .remove-btn {
            display: inline-block;
            padding: 5px 10px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
            cursor: pointer;
            margin-left: 10px;
        }

        .remove-btn:hover {
            background-color: #c82333;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }

    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

<a href="Shops.php" class="back-button">
    <i class="fas fa-arrow-left"></i>
</a>

<div class="container">
    <header>
        <h1>Products in Store #<?= $shop_id; ?></h1>
    </header>

    <div class="product-list">
        <?php while ($product = $products->fetch_assoc()): ?>
            <div class="product-item">
                <img src="<?= $product['image_url']; ?>" alt="<?= $product['product_name']; ?>">
                <h3><?= $product['product_name']; ?></h3>
                <p>Price: <?= $product['price']; ?></p>
                <p>Stock: <?= $product['stock']; ?></p>
                <a href="Products.php?product_id=<?= $product['product_id']; ?>&shop_id=<?= $shop_id; ?>">Add to Cart</a>
            </div>
        <?php endwhile; ?>
    </div>

    <button class="toggle-cart" onclick="toggleCart()">Toggle Shopping Cart</button>

    <!-- Shopping Cart -->
    <div id="shoppingCart" class="cart" style="display: none;">
        <h2>Shopping Cart</h2>
        <?php if (!empty($_SESSION['carts'][$shop_id])): ?>
            <ul>
                <?php foreach ($_SESSION['carts'][$shop_id] as $id => $cart_item): ?>
                    <li><?= $cart_item['name']; ?> - <?= $cart_item['quantity']; ?> x <?= $cart_item['price']; ?>
                        <a href="Products.php?remove_id=<?= $id; ?>&shop_id=<?= $shop_id; ?>" class="remove-btn">Remove</a>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p>Total: <?= $totalAmount; ?></p>
            <a href="Payment.php?shop_id=<?= $shop_id; ?>" class="checkout-btn">Proceed to Checkout</a>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    function toggleCart() {
        var cart = document.getElementById("shoppingCart");
        if (cart.style.display === "none") {
            cart.style.display = "block";
        } else {
            cart.style.display = "none";
        }
    }
</script>

</body>
</html>
