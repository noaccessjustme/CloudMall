<?php
require_once 'session.php';

// Check if the user is already logged in
if (isset($_SESSION["user_id"])) {
    header("Location: dashboard.php"); // Redirect to the dashboard if already logged in
    exit();
}

// Initialize error variables
$emailErr = $passwordErr = "";
$email = $password = "";

// Database connection
$servername = "localhost";
$username = "root";
$password_db = "";
$dbname = "cloud_mall";

$conn = new mysqli($servername, $username, $password_db, $dbname);

// Check if connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
    }

    // Validate password
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = test_input($_POST["password"]);
    }

    // If no validation errors, check credentials in the database
    if (empty($emailErr) && empty($passwordErr)) {
        // Prepare SQL query to fetch user
        $query = $conn->prepare("SELECT user_id, hash_password FROM users WHERE email = ?");
        $query->bind_param("s", $email);
        $query->execute();
        $result = $query->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();

            // Verify the password with the hash stored in the database
            if (password_verify($password, $row['hash_password'])) {
                // Set session variables upon successful login
                $_SESSION["user_id"] = $row['user_id'];
                $_SESSION["email"] = $email;

                // Redirect to the dashboard page
                header("Location: OnlineShopping.php");
                exit();
            } else {
                $passwordErr = "Incorrect password";
            }
        } else {
            $emailErr = "No account found with that email";
        }

        $query->close();
    }
}

$conn->close();

// Function to sanitize input data
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    <style>
    
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Full-page video background */
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Roboto', sans-serif;
        }

        /* Video Background Styling */
        .video-background {
            position: fixed;
            right: 0;
            bottom: 0;
            min-width: 100%;
            min-height: 100%;
            z-index: -1;
        }

        /* Container styling */
        .container {
            position: relative;
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }

        /* Form box styling */
        .form-box {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.3);
            color: #fff;
            border: 2px solid #FFD700;
        }

        /* Header text */
        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #FFD700;
            font-size: 22px;
            font-weight: bold;
        }

        /* Input fields */
        .input-group {
            margin-bottom: 18px;
        }

        .input-group label {
            display: block;
            margin-bottom: 6px;
            color: #FFD700;
        }

        .input-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #FFD700;
            border-radius: 8px;
            font-size: 16px;
            color: #000;
            background-color: #fff;
        }

        .input-group input:focus {
            outline: none;
            background-color: #f9f9f9;
        }

        /* Error message styling */
        .error-message {
            color: red;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        /* Button styling */
        button {
            width: 100%;
            padding: 12px;
            background-color: #FFD700;
            border: none;
            border-radius: 8px;
            color: #000; 
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #333;
            color: #fff; 
        }

        /* Paragraph and link */
        p {
            text-align: center;
            margin-top: 20px;
            color: #fff; 
        }

        p a {
            color: #FFD700;
            text-decoration: none;
        }

        p a:hover {
            text-decoration: underline;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: #ffffff;
            background-color: #333;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .back-button i {
            margin-right: 8px;
            font-size: 18px;
        }

        .back-button:hover {
            background-color: #555;
        }

    </style>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>

    <a href="OnlineShopping.php" class="back-button">
    <i class="fas fa-arrow-left"></i></a>

    <header>
        <p>Login And Enjoy Your Shopping </p>
    </header>

    <video autoplay muted loop class="video-background">
        <source src="https://www.youtube.com/watch?v=siftDMqiq-E" type="video/mp4">
        Your browser does not support the video tag.
    </video>

    <!-- Login Form -->
    <div class="container">
        <div class="form-box">
            <h2>Login</h2>
            <form action="Login.php" method="POST" id="login-form">
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>" required>
                    <span class="error-message"><?php echo $emailErr; ?></span>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <span class="error-message"><?php echo $passwordErr; ?></span>
                </div>
                <button type="submit">Login</button>
            </form>
            <p>Don't have an account? <a href="SignUp.php">Sign up here</a></p>
        </div>
    </div>

</body>
</html>
