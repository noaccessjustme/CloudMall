<?php
// Session configurations
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);

// Secure session cookie settings
session_set_cookie_params([
    'lifetime' => 1800,   // 30 minutes session lifetime
    'domain'   => 'localhost',
    'path'     => '/',
    'secure'   => false,  // Set to true in production with HTTPS
    'httponly' => true,   // Prevent JavaScript access to session cookie
]);

session_start(); // Start the session

// Regenerate session ID every 30 minutes
if (!isset($_SESSION["last_regeneration"])) {
    $_SESSION["last_regeneration"] = time();
}

if (time() - $_SESSION["last_regeneration"] >= 1800) {
    session_regenerate_id(true);
    $_SESSION["last_regeneration"] = time();
}
?>
